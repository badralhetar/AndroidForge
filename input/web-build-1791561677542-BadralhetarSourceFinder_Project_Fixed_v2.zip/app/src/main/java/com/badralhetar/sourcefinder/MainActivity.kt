package com.badralhetar.sourcefinder

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var list: ListView
    private lateinit var search: EditText
    private lateinit var status: TextView
    private val apps = mutableListOf<AppEntry>()
    private var shown = mutableListOf<AppEntry>()

    data class AppEntry(val label: String, val packageName: String, val version: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF123B5D.toInt()
        window.navigationBarColor = 0xFF123B5D.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 12)
            setBackgroundColor(0xFFF4F7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "Badralhetar Source Finder"
            textSize = 23f; setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF123B5D.toInt()); gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "اختر تطبيقًا لفحص مصدر التثبيت والبحث عن مصدره الأصلي المحتمل"
            textSize = 14f; gravity = Gravity.CENTER
            setTextColor(0xFF34495E.toInt()); setPadding(0, 10, 0, 16)
        }
        search = EditText(this).apply {
            hint = "ابحث باسم التطبيق..."
            singleLine = true
            textSize = 16f
        }
        status = TextView(this).apply {
            text = "المصدر الأصلي قد لا يكون قابلًا للاسترجاع من الهاتف."
            textSize = 12f; setTextColor(0xFF555555.toInt()); setPadding(2, 8, 2, 8)
        }
        list = ListView(this)
        root.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(subtitle, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(search, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(status, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        loadApps()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { filterApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        list.setOnItemClickListener { _, _, position, _ -> showDetails(shown[position]) }
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val pm = packageManager
        val all = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        apps.clear()
        for (info in all) {
            if (info.packageName == packageName) continue
            val label = pm.getApplicationLabel(info).toString()
            val version = try { pm.getPackageInfo(info.packageName, 0).versionName ?: "غير معروف" } catch (_: Exception) { "غير معروف" }
            apps.add(AppEntry(label, info.packageName, version))
        }
        apps.sortBy { it.label.lowercase() }
        filterApps("")
    }

    private fun filterApps(query: String) {
        shown = apps.filter { it.label.contains(query, true) || it.packageName.contains(query, true) }.toMutableList()
        // Use a custom adapter so both the app name and package name are visible.
        list.adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: android.view.View?, parent: ViewGroup): android.view.View {
                val box = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12)
                }
                box.removeAllViews()
                val a = TextView(this@MainActivity).apply { text = shown[position].label; textSize = 17f; setTextColor(0xFF17202A.toInt()); setTypeface(null, Typeface.BOLD) }
                val b = TextView(this@MainActivity).apply { text = shown[position].packageName; textSize = 12f; setTextColor(0xFF566573.toInt()) }
                box.addView(a); box.addView(b)
                return box
            }
        }
        status.text = "التطبيقات الظاهرة: ${shown.size} — اختر تطبيقًا لعرض التفاصيل."
    }

    private fun showDetails(app: AppEntry) {
        val pm = packageManager
        // getInstallSourceInfo was added in Android 11 (API 30).
        val installInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try { pm.getInstallSourceInfo(app.packageName) } catch (_: Exception) { null }
        } else null
        val installer = installInfo?.installingPackageName ?: "غير متاح من هذا الإصدار"
        val initiator = installInfo?.initiatingPackageName ?: "غير متاح"
        val originating = installInfo?.originatingPackageName ?: "غير متاح"
        val details = "اسم التطبيق: ${app.label}\n\nالحزمة: ${app.packageName}\n\nالإصدار: ${app.version}\n\nجهة التثبيت المسجّلة: ${friendlyInstaller(installer)}\n\nالجهة التي بدأت التثبيت (إن توفرت): $initiator\n\nالمصدر الأصلي المسجّل (إن توفر): $originating\n\nتنبيه مهم: هذه البيانات لا تكشف بالضرورة رابط الموقع الذي نُزّل منه ملف APK. قد يظهر متجر أو مدير ملفات بدل الموقع الأصلي. البحث على الإنترنت يعرض نتائج محتملة وليست إثباتًا للمصدر."
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("نتيجة الفحص")
            .setMessage(details)
            .setPositiveButton("ابحث على الإنترنت") { _, _ -> searchWeb(app) }
            .setNeutralButton("نسخ التفاصيل") { _, _ ->
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Source Finder", details))
                Toast.makeText(this, "تم نسخ التفاصيل", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إغلاق", null).create()
        dialog.show()
    }

    private fun friendlyInstaller(pkg: String): String = when (pkg) {
        "com.android.vending" -> "Google Play"
        "com.sec.android.app.samsungapps" -> "Samsung Galaxy Store"
        "com.android.packageinstaller", "com.google.android.packageinstaller" -> "مثبّت حزم أندرويد"
        "com.google.android.documentsui", "com.sec.android.app.myfiles" -> "مدير الملفات"
        "غير متاح من هذا الإصدار" -> pkg
        else -> "$pkg (اسم الحزمة المسجّل)"
    }

    private fun searchWeb(app: AppEntry) {
        val q = Uri.encode("\"${app.packageName}\" ${app.label} الموقع الرسمي تنزيل")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q"))
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح المتصفح. تحقق من اتصال الإنترنت.", Toast.LENGTH_LONG).show()
        }
    }
}
